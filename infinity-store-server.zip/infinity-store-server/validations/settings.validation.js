const { z } = require("zod");

const updateSettingsSchema = z.object({
  siteName: z.string().trim().min(1, "Site name is required"),
  logo: z.string().min(1, "Logo cannot be empty"),
});

module.exports = {
  updateSettingsSchema,
};
